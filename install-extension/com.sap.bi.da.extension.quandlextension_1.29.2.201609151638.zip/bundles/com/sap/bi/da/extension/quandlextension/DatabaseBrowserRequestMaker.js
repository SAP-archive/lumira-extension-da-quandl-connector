/**
 * Created by Niklas on 15.09.2016.
 */
jQuery.sap.declare("com.sap.bi.da.extension.quandlextension.DatabaseBrowserRequestMaker");

com.sap.bi.da.extension.quandlextension.DatabaseBrowserRequestMaker = function(fServiceCall) {
    this.fServiceCall = fServiceCall;
};

com.sap.bi.da.extension.quandlextension.DatabaseBrowserRequestMaker.prototype.getDatabaseList = function(elementsPerPage, page) {
    return {
        "databases":[
            {
                "id":33,
                "name":"National Stock Exchange of India",
                "database_code":"NSE",
                "description":"Stock and index data from the National Stock Exchange of India.",
                "datasets_count":2014,
                "downloads":6681467,
                "premium":false,
                "image":"https://quandl-data-upload.s3.amazonaws.com/uploads/source/profile_image/33/thumb_nse.png"
            }
        ],
        "meta":{
            "query":"",
            "per_page":100,
            "current_page":1,
            "prev_page":null,
            "total_pages":1,
            "total_count":1,
            "next_page":null,
            "current_first_item":1,
            "current_last_item":1
        }
    };
};